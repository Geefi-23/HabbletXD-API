<style>body { padding: 0; margin: 0 }</style>
<img src="http://habbletxd.com/uploads/avatar.png" />